// JavaScript file for any interactivity
document.addEventListener("DOMContentLoaded", function() {
    console.log("GTA BD ROYAL GAMER page loaded and ready.");
    // Add interactive features here if needed
});
